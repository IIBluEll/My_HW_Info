﻿using MyHwInfo.Core.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyHwInfo.Core.Presenter
{
    public class HwInfo_presenter
    {
        private readonly IMainWindowView _view;
        private readonly HwInfo_model _model;

        public HwInfo_presenter(IMainWindowView view, HwInfo_model model)
        {
            _view = view;
            _model = model;
        }

        public void OnLoadHWInfoButtonClicked()
        {
            var tInfo = _model.GetHardWareInfo();
            _view.DisplayHardwareInfo(tInfo);
        }
    }
}
