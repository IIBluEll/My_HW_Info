﻿using System.Management;
using System.Text;

namespace MyHwInfo.Core.Model
{
    public class HwInfo_model
    {
        public string GetHardWareInfo()
        {
            var tBuilder = new StringBuilder();

            tBuilder.AppendLine($"Machine Name : {Environment.MachineName}");
            tBuilder.AppendLine($"OS Version   : {Environment.OSVersion}");
            tBuilder.AppendLine($"64-bit OS    : {Environment.Is64BitOperatingSystem}");
            tBuilder.AppendLine($"CPU          : {GetCpuName()}");
            tBuilder.AppendLine($"RAM (MB)     : {GetTotalMemoryMb()}");

            return tBuilder.ToString();
        }
        private string GetCpuName()
        {
            try
            {
                using var tSearcher = new ManagementObjectSearcher("select Name from Win32_Processor");

                foreach ( var tObj in tSearcher.Get())
                {
                    return tObj[ "Name" ]?.ToString() ??
                        "Unknown";
                }
            }
            catch ( Exception ex )
            {
                return "Unknown";
            }

            return "Unknown";
        }

        private long GetTotalMemoryMb()
        {
            try
            {
                using var tSearcher = new ManagementObjectSearcher("select TotalPhysicalMemory from Win32_ComputerSystem");
                foreach ( var tObj in tSearcher.Get() )
                {
                    if ( tObj[ "TotalPhysicalMemory" ] is ulong tBytes )
                    {
                        return (long)( tBytes / ( 1024 * 1024 ) );
                    }
                }
            }
            catch
            {
                return 0;
            }

            return 0;
        }
    }
}
