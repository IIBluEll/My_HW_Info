﻿using MyHwInfo.Core.Model;
using MyHwInfo.Core.Presenter;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MyHwInfo
{
    public interface IMainWindowView
    {
        void DisplayHardwareInfo(string hardwareText);
    }

    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window, IMainWindowView
    {
        private readonly HwInfo_presenter _presenter;

        public MainWindow()
        {
            InitializeComponent();

            var tModel = new HwInfo_model();
            _presenter = new HwInfo_presenter(this , tModel);
        }

        public void DisplayHardwareInfo(string hardwareText)
        {
            hardwareInfoTxt.Text = hardwareText;
        }

        private void OnLoadInfoBtnClicked(object sender , RoutedEventArgs e)
        {
            _presenter.OnLoadHWInfoButtonClicked();
        }
    }
}